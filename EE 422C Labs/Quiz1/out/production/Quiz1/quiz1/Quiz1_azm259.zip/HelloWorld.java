// Main.java
// * EE422C Quiz 1 submission by
// * Ali Ziyaan Momin
// * AZM259
// * 16470
// * Fall 2016  */

package quiz1;

public class HelloWorld {
    public static void hello(){
        System.out.println("Hello, World");
    }
    public static void printMsg(){
        System.out.println("I am Bob! Nice to meet you!");
    }
}
