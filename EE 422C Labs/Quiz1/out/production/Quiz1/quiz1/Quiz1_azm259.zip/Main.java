// Main.java
// EE422C Quiz 1 submission by
// Ali Ziyaan Momin
// AZM259
// 16470
// Fall 2016

package quiz1;

public class Main {
    public static void main(String [] args){
        HelloWorld.hello();
        HelloWorld.printMsg();
    }
}
